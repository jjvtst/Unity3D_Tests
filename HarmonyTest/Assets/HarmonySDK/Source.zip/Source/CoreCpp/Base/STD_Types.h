#ifndef _STD_TYPES_H_
#define _STD_TYPES_H_

#include <string>

#define STD_String std::string

#endif /* _STD_TYPES_H_ */
