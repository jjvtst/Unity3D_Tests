#ifndef __FXVERTSHADERDX11_HLSL_H__
#define __FXVERTSHADERDX11_HLSL_H__

const char *g_fxVertShaderDX11_hlsl =
"\n\
\n\
//  a_boneParams\n\
//  | boneIndex1      | boneWeight1     | boneIndex2      | boneWeight2     |\n\
//  |-----------------|-----------------|-----------------|-----------------|\n\
//  | (float) 32 bits | (float) 32 bits | (float) 32 bits | (float) 32 bits |\n\
\n\
struct InputVertex\n\
{\n\
  float3 a_position       : POSITION;\n\
  float4 a_color          : COLOR;\n\
  float2 a_texCoord0      : TEXCOORD0;\n\
\n\
  float4 a_fxParams0      : TEXCOORD1;\n\
  float4 a_fxViewport0    : TEXCOORD2;\n\
\n\
  float4 a_boneParams     : TEXCOORD3;\n\
};\n\
\n\
struct OutputVertex\n\
{\n\
  float4 v_position                     : SV_POSITION;\n\
  float4 v_color                        : COLOR;\n\
  float2 v_texCoord0                    : TEXCOORD0;\n\
\n\
  float4 v_fxParams0                    : TEXCOORD1;\n\
  nointerpolation float4 v_fxViewport0  : TEXCOORD2;\n\
\n\
};\n\
\n\
cbuffer ConstantBuffer : register(b0)\n\
{\n\
  //  Model view projection matrix\n\
  float4x4 u_mvpMatrix;\n\
\n\
  //  Array of bone matrices.  Index 0 is identity matrix.\n\
  float4x4 u_boneMatrix[32];\n\
}\n\
\n\
OutputVertex main( InputVertex i_vertex )\n\
{\n\
  float4x4 skinMatrix = i_vertex.a_boneParams.y * u_boneMatrix[ i_vertex.a_boneParams.x ] +\n\
                        i_vertex.a_boneParams.w * u_boneMatrix[ i_vertex.a_boneParams.z ];\n\
\n\
  OutputVertex o_vertex;\n\
\n\
  o_vertex.v_position = mul( u_mvpMatrix, mul( skinMatrix, float4( i_vertex.a_position, 1.0f ) ) );\n\
  o_vertex.v_color = i_vertex.a_color.bgra;\n\
  o_vertex.v_texCoord0 = i_vertex.a_texCoord0;\n\
\n\
  o_vertex.v_fxParams0 = i_vertex.a_fxParams0;\n\
  o_vertex.v_fxViewport0 = i_vertex.a_fxViewport0;\n\
\n\
  return o_vertex;\n\
}\n\
\n\
";

#endif /* __FXVERTSHADERDX11_HLSL_H__ */