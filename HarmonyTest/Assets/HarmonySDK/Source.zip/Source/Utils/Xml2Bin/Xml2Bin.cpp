
#include "Base/MEM_Override.h"

#include "Base/IO_PersistentStore.h"
#include "Base/IO_File.h"
#include "Base/PL_FileSpec.h"
#include "Base/UT_String.h"
#include "Xml/XML_ProjectLoader.h"
#include "Render/RD_ClipDataCore.h"
#include "Render/RD_SpriteSheetCore.h"
#include "Tree/TR_NodeTree.h"

#include <set>
#include <iostream>

void usage()
{
  STD_String howto(
        "Usage: Xml2Bin [sceneFolder]\n"
        "\n"
        "This program converts the xml data in the specified scene folder to\n"
        "optimized binary files.\n"
        "\n"
        "Options:\n"
        "  -?|-h|-help|--help \n"
       );

  printf( "%s", howto.c_str() );
}

int main ( int /*argc*/, char *argv[] )
{
#ifdef MEM_DEBUG_OVERRIDE
  MEM_DebugOverride::initialize();
#endif

  if (*argv) ++argv; // skip the program name
  while (*argv && **argv == '-')
  {
    STD_String arg(*argv);

    if ( arg.compare( "-help" ) == 0 ||
         arg.compare( "-?" ) == 0 ||
         arg.compare( "-h" ) == 0 ||
         arg.compare( "--help" ) == 0 )
    {
      usage();
#ifdef MEM_DEBUG_OVERRIDE
      MEM_DebugOverride::deinitialize();
#endif
      return 0;
    }

    //  For if we have options
    ++argv;
  }

  if ( !*argv )
  {
    fprintf( stderr, "No scene folder specified.\n" );
    usage();
#ifdef MEM_DEBUG_OVERRIDE
    MEM_DebugOverride::deinitialize();
#endif
    return -1;
  }

  STD_String projectFolder( *argv );
  XML_ProjectLoader::StringCol_t clipNames;

  if ( !PL_FileInfo( projectFolder.c_str() ).IsFolder() )
  {
    fprintf( stderr, "Could not find folder '%s'\n", projectFolder.c_str() );
#ifdef MEM_DEBUG_OVERRIDE
    MEM_DebugOverride::deinitialize();
#endif
    return -1;
  }

  //  Convert clips to binary
  XML_ProjectLoader::loadStageClipNames( projectFolder, clipNames );

  for ( XML_ProjectLoader::StringCol_t::const_iterator i = clipNames.begin(), iEnd = clipNames.end() ; i!=iEnd ; ++i )
  {
    STD_String clipName = *i;

    printf( "Converting clip '%s' to binary.\n", clipName.c_str() );

    RD_ClipDataCore clipData;
    XML_ProjectLoader::loadStageClip( projectFolder, clipName, &clipData );

    PL_FileSpec fileSpec( ( projectFolder + "/stages" ).c_str() );
    fileSpec.CreateFolder();

    fileSpec.Add( ( clipName + ".bin" ).c_str() );

    IO_File file;
    if (file.createForOutput(fileSpec))
    {
      IO_PersistentStore store(file);
      clipData.store( store );

      file.close();
    }
  }

  //  Convert sprite sheets to binary
  XML_ProjectLoader::StringPairCol_t sheetNames;
  XML_ProjectLoader::loadSpriteSheetNames( projectFolder, sheetNames );

  for ( XML_ProjectLoader::StringPairCol_t::const_iterator i = sheetNames.begin(), iEnd = sheetNames.end() ; i!=iEnd ; ++i )
  {
    STD_String sheetName = i->first;
    STD_String sheetResolution = i->second;

    printf( "Converting sprite sheet '%s' with resolution '%s' to binary.\n", sheetName.c_str(), sheetResolution.c_str() );

    RD_SpriteSheetCore sheet;
    XML_ProjectLoader::loadSpriteSheet( projectFolder, sheetName, sheetResolution, &sheet );

    PL_FileSpec fileSpec( ( projectFolder + "/spriteSheets" ).c_str() );
    fileSpec.CreateFolder();

    fileSpec.Add( ( sheetName + "-" + sheetResolution + ".bin" ).c_str() );

    IO_File file;
    if (file.createForOutput(fileSpec))
    {
      IO_PersistentStore store(file);
      sheet.store( store );

      file.close();
    }
  }

#ifdef MEM_DEBUG_OVERRIDE
  MEM_DebugOverride::deinitialize();
#endif

}
